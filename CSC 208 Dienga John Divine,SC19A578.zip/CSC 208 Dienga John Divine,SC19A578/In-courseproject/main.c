#include <stdio.h>
#include <stdlib.h>
void decider(int*a,int*b){
    int temp;
    if(*a<*b){
        temp=*a;
        *a=*b;
        *b=temp;
    }
}
int computer(int a,int b){
    int c,r,q;
    do{
            /*Conflict:handled by randomization*/
            while(r==0&&(q==0)){
        c=rand()%2;
        switch(c){
              case 1:
                  r=a%b;
              case 0:
                  q=a/b;
        }
            }// end of while loop
    /* Display each step*/
            printf("%d=%d(%d)+%d\n",a,q,b,r);
    /*reassignment*/
            a=b;
            b=r;
            //Ensuring line 20 is true
            r=0;q=0;}
            while(b!=0);//End of do-while loop
    return a;
}

int main()
{
   int a,c,b;
   printf("Enter two integers\n");
   scanf("%d %d",&a,&b);
   decider(&a,&b);
   c=computer(a,b);
   printf("gcd[%d,%d]=%d",a,b,c);
   return 0;
}
